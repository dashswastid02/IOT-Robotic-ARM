# Project media

Add your own authentic project photos, wiring diagram, and demo video here.

Suggested filenames:
- `assembled-robotic-arm.jpg`
- `wiring-diagram.png`
- `web-control-demo.mp4`

Do not add stock images as if they show your actual build. Update the README with the hardware configuration you personally tested.
