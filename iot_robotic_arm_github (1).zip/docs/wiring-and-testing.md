# Wiring and testing notes

## Example signal connections
- GPIO 13 → Base servo signal
- GPIO 14 → Shoulder servo signal
- GPIO 25 → Elbow servo signal
- GPIO 26 → Gripper servo signal
- ESP32 GND ↔ external servo-supply GND

Power each servo from a regulated external supply that meets its voltage and stall-current needs. The supply voltage must match the servos. Do not connect an external 5 V rail to an ESP32 GPIO. Do not power servos from the ESP32 3.3 V pin.

## Bring-up procedure
1. Disconnect power and check wiring.
2. Upload the firmware with servos disconnected if practical.
3. Confirm the Wi-Fi AP appears and open the control page.
4. Power the servos from the correctly rated external supply and connect common ground.
5. Test one servo at a time with no load.
6. Set safe limits in `SERVO_MIN` and `SERVO_MAX`.
7. Check for mechanical binding, hot servos, brownouts, or unexpected movement; disconnect power if these occur.

## Validation record
Fill this in after testing real hardware:

| Test | Result |
|---|---|
| ESP32 AP starts | Not tested |
| Web page loads on phone/laptop | Not tested |
| Base servo moves safely | Not tested |
| Shoulder servo moves safely | Not tested |
| Elbow servo moves safely | Not tested |
| Gripper opens/closes | Not tested |
| Angle limits verified | Not tested |
