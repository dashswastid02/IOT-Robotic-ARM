/*
  IoT-Based Robotic Arm — ESP32 reference implementation
  Hardware: ESP32 + 4 hobby servo motors
  Library: ESP32Servo (install via Arduino Library Manager)

  This is a portfolio reference implementation, not verified original
  code from the project mentioned in the resume.

  IMPORTANT:
  - Power servos from an appropriate external regulated supply.
  - Join external servo supply GND to ESP32 GND.
  - Never power servos from the ESP32 3.3 V output.
  - Adjust angle limits for your mechanism before operation.
*/

#include <WiFi.h>
#include <WebServer.h>
#include <ESP32Servo.h>

const char* AP_SSID = "RoboticArm-ESP32";
const char* AP_PASSWORD = "armcontrol123"; // Change before use; 8+ chars

WebServer server(80);

static const uint8_t SERVO_COUNT = 4;
const uint8_t SERVO_PINS[SERVO_COUNT] = {13, 14, 25, 26};

// These are conservative examples only. Tune for your actual mechanism.
const int SERVO_MIN[SERVO_COUNT] = {10, 20, 20, 20};
const int SERVO_MAX[SERVO_COUNT] = {170, 160, 160, 100};
const int SERVO_START[SERVO_COUNT] = {90, 90, 90, 30};

const char* SERVO_NAMES[SERVO_COUNT] = {
  "Base", "Shoulder", "Elbow", "Gripper"
};

Servo servos[SERVO_COUNT];
int currentAngles[SERVO_COUNT];

const char INDEX_HTML[] PROGMEM = R"HTML(
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>ESP32 Robotic Arm</title>
<style>
  :root { color-scheme: dark; }
  * { box-sizing: border-box; }
  body {
    margin: 0; font-family: system-ui, sans-serif; background: #101722;
    color: #eef3fa; padding: 22px;
  }
  main { max-width: 760px; margin: auto; }
  h1 { margin-bottom: 6px; }
  .muted { color: #aebbd0; }
  .panel {
    background: #1b2736; border: 1px solid #334258; border-radius: 16px;
    padding: 18px; margin: 16px 0;
  }
  .axis { margin: 20px 0; }
  .axis-head { display: flex; justify-content: space-between; gap: 12px; }
  input[type=range] { width: 100%; accent-color: #65b7ff; margin-top: 12px; }
  button {
    border: 0; border-radius: 10px; padding: 11px 16px; margin: 4px;
    background: #2c8bd9; color: white; font-weight: 650; cursor: pointer;
  }
  button.secondary { background: #46566b; }
  .status { min-height: 24px; color: #a9d9ff; }
  .small { font-size: .9rem; }
</style>
</head>
<body>
<main>
  <h1>IoT Robotic Arm</h1>
  <div class="muted">ESP32 local Wi-Fi controller · Four servo axes</div>
  <section class="panel">
    <p class="small muted">Move one axis at a time. Test without a load and keep hands clear of joints.</p>
    <div id="controls"></div>
    <button onclick="sendAll()">Send all positions</button>
    <button class="secondary" onclick="resetPose()">Reset pose</button>
    <div class="status" id="status" role="status" aria-live="polite"></div>
  </section>
  <section class="panel">
    <strong>Connection</strong>
    <p class="muted small">Connect to <code>RoboticArm-ESP32</code> and open <code>http://192.168.4.1</code>.</p>
  </section>
</main>
<script>
const axes = [
  {id:0, name:"Base", min:10, max:170, start:90},
  {id:1, name:"Shoulder", min:20, max:160, start:90},
  {id:2, name:"Elbow", min:20, max:160, start:90},
  {id:3, name:"Gripper", min:20, max:100, start:30}
];
const values = axes.map(a => a.start);
const controls = document.getElementById("controls");

axes.forEach(a => {
  const div = document.createElement("div");
  div.className = "axis";
  div.innerHTML = `<div class="axis-head"><label for="s${a.id}">${a.name}</label><strong><span id="v${a.id}">${a.start}</span>°</strong></div>
  <input id="s${a.id}" type="range" min="${a.min}" max="${a.max}" value="${a.start}" aria-label="${a.name} angle">`;
  controls.appendChild(div);
  div.querySelector("input").addEventListener("input", e => {
    values[a.id] = Number(e.target.value);
    document.getElementById(`v${a.id}`).textContent = values[a.id];
  });
  div.querySelector("input").addEventListener("change", () => sendAxis(a.id));
});

async function sendAxis(id) {
  const status = document.getElementById("status");
  status.textContent = "Sending command…";
  try {
    const body = new URLSearchParams({servo: id, angle: values[id]});
    const response = await fetch("/move", {
      method: "POST",
      headers: {"Content-Type": "application/x-www-form-urlencoded"},
      body
    });
    const data = await response.json();
    if (!response.ok || !data.ok) throw new Error(data.error || "Command rejected");
    status.textContent = `${axes[id].name} set to ${data.angle}°`;
  } catch (err) {
    status.textContent = `Error: ${err.message}. Check Wi-Fi connection.`;
  }
}
async function sendAll() {
  for (let i = 0; i < axes.length; i++) await sendAxis(i);
}
function resetPose() {
  axes.forEach(a => {
    values[a.id] = a.start;
    document.getElementById(`s${a.id}`).value = a.start;
    document.getElementById(`v${a.id}`).textContent = a.start;
  });
  sendAll();
}
</script>
</body>
</html>
)HTML";

void sendJsonError(int statusCode, const String& message) {
  String json = "{\"ok\":false,\"error\":\"" + message + "\"}";
  server.send(statusCode, "application/json", json);
}

void handleRoot() {
  server.send_P(200, "text/html; charset=utf-8", INDEX_HTML);
}

void handleMove() {
  if (!server.hasArg("servo") || !server.hasArg("angle")) {
    sendJsonError(400, "Required fields: servo and angle");
    return;
  }

  // Reject malformed values instead of silently converting arbitrary strings.
  String servoText = server.arg("servo");
  String angleText = server.arg("angle");
  if (servoText.length() == 0 || angleText.length() == 0) {
    sendJsonError(400, "Empty servo or angle");
    return;
  }

  for (size_t i = 0; i < servoText.length(); i++) {
    if (!isDigit(servoText[i])) {
      sendJsonError(400, "Servo index must be an integer");
      return;
    }
  }
  // Permit a leading minus sign for angle input, then clamp to safe range.
  size_t angleStart = (angleText[0] == '-') ? 1 : 0;
  if (angleStart == angleText.length()) {
    sendJsonError(400, "Angle must be an integer");
    return;
  }
  for (size_t i = angleStart; i < angleText.length(); i++) {
    if (!isDigit(angleText[i])) {
      sendJsonError(400, "Angle must be an integer");
      return;
    }
  }

  int index = servoText.toInt();
  int requestedAngle = angleText.toInt();
  if (index < 0 || index >= SERVO_COUNT) {
    sendJsonError(400, "Servo index out of range");
    return;
  }

  int safeAngle = constrain(requestedAngle, SERVO_MIN[index], SERVO_MAX[index]);
  servos[index].write(safeAngle);
  currentAngles[index] = safeAngle;

  Serial.printf("%s -> %d degrees (requested %d)\n",
                SERVO_NAMES[index], safeAngle, requestedAngle);

  String json = "{\"ok\":true,\"servo\":\"";
  json += SERVO_NAMES[index];
  json += "\",\"angle\":";
  json += String(safeAngle);
  json += "}";
  server.send(200, "application/json", json);
}

void handleNotFound() {
  server.send(404, "text/plain", "Not found");
}

void setup() {
  Serial.begin(115200);
  delay(300);

  // Standard hobby servos commonly use 50 Hz PWM. Verify requirements.
  for (uint8_t i = 0; i < SERVO_COUNT; i++) {
    servos[i].setPeriodHertz(50);
    servos[i].attach(SERVO_PINS[i], 500, 2400);
    currentAngles[i] = SERVO_START[i];
    servos[i].write(currentAngles[i]);
    delay(150);
  }

  WiFi.mode(WIFI_AP);
  bool apStarted = WiFi.softAP(AP_SSID, AP_PASSWORD);
  if (!apStarted) {
    Serial.println("ERROR: Wi-Fi access point failed to start.");
  } else {
    Serial.println();
    Serial.println("Robotic Arm Wi-Fi AP started");
    Serial.print("SSID: ");
    Serial.println(AP_SSID);
    Serial.print("Open: http://");
    Serial.println(WiFi.softAPIP());
  }

  server.on("/", HTTP_GET, handleRoot);
  server.on("/move", HTTP_POST, handleMove);
  server.onNotFound(handleNotFound);
  server.begin();
  Serial.println("HTTP server started on port 80.");
}

void loop() {
  server.handleClient();
}
